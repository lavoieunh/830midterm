package strategery;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

//import static org.mockito.Mockito.*;

class RunningItTest {

	
	@Test
	public void testAuthor() { 

		//Scanner library = new Scanner(System.in);

	    String choice = "author";
	    
	   InputStream in = new ByteArrayInputStream(choice.getBytes());
	    System.setIn(in);

	    assertEquals("author", choice);
	}
	
	@Test 
	public void testTitle() { 
		String choice = "title"; 
		InputStream in = new ByteArrayInputStream(choice.getBytes()); 
		System.setIn(in); 
		
		assertEquals("title", choice);
	}
	
	
	public void testYearsPub() { 
		String choice = "1990"; 
		InputStream in = new ByteArrayInputStream(choice.getBytes()); 
		System.setIn(in);
		
	} 
	
	public void testFailure() { 
		String choice = "Not a choice"; 
		InputStream in = new ByteArrayInputStream(choice.getBytes()); 
		System.setIn(in);
	}
	
}
