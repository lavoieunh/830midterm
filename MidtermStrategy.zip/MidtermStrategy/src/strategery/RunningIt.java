package strategery;


import java.util.*;  

public class RunningIt {

	    public static void main(String[] args) {
	    	
	    	
		Scanner library = new Scanner(System.in);

	    	System.out.println("Would you like to sort by Author, Title, or Year Published");
	    	String choice = library.nextLine().toLowerCase();
	    	library.close();
	    	
	    	if(choice.equals("author")) { 
		Authors auth = new Authors(); 
		System.out.println(auth);
		  } 
	    	else if(choice.equals("title")) { 
	    		Titles title = new Titles(); 
	    		System.out.println(title);
	    	} 
	    	
	    	else if (choice.equals("year published")) { 
	    		YearPub years = new YearPub();
	    		System.out.println(years);
	    	}
		    	else { 
		    		System.out.println("Invalid Choice");
		    	}
	    }
}


	
	




