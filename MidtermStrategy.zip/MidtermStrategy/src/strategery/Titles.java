package strategery;

//import java.util.ArrayList;
//import java.util.Collections;
import java.util.*;

public class Titles {
	
		private String titleList; 
			
			

			public String toString() { 
				return titleList;
			}
			
			public Titles() { 
			 List<String> titleList = new ArrayList<String>();
		     titleList.add("Farenheit 451");
		     titleList.add("Hunt for Red October");
		     titleList.add(" The Hobbit");
		     titleList.add("Tom Sawyer");
		     titleList.add("The Stand");
		     titleList.add("Kiss the Girls");
		     titleList.add("For Whom the Bell Tolls");
		     titleList.add("Big Sur");
		     titleList.add("Christmas Carol");
		     titleList.add("How Much Land Does a Man Need");
		     titleList.add("Great Gatsby");
		     titleList.add("Dubliners");
		     titleList.add("Murder on the Orient Express");
		     titleList.add("The Pit and the Pendulum");
		     titleList.add("As I Lay Dying");
		     titleList.add("Of Mice and Men");
		     titleList.add("The Firm");
		     titleList.add("1984");
		     titleList.add("H.P. Lovecraft");
		     titleList.add("James and the Giant Peach");
		     titleList.add("Comp 830 - Learn Java");
		     
		     Collections.sort(titleList);

		     System.out.println(titleList);

	}
}

