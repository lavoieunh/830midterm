package strategery;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertTrue;


import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

class AuthorsTest {

	@Test
	public void testAuthors() { 
		equals("authlist" != null);

	} 
	
	@Test 
	public void testAuthors2() { 
		List<String> authList = service.getMyItems();
		assertTrue(authList.contains(new String("Author")));
		
		//assertThat(myClass.getMyItems()).extracting("Author").contains("Faulkner");
	}

}
