package strategery;

import java.util.*;

public  class Authors {
	private String authList; 
		
		
		//public BookSort1(String authors) { 
		//	this.authors=authors;
		//}

		public String toString() { 
			return authList;
		}
		
		public Authors() { 
		 List<String> authList = new ArrayList<String>();
	     authList.add("Ray Bradbury");
	     authList.add("Tom Clancy");
	     authList.add(" J.R.R Tolkien");
	     authList.add("Mark Twain");
	     authList.add("Stephen King");
	     authList.add("James Patterson");
	     authList.add("Ernest Hemingway");
	     authList.add("Jack Keourac");
	     authList.add("Charles Dickens");
	     authList.add("Leo Tolstoy");
	     authList.add("F Scott Fitzgerald");
	     authList.add("James Joyce");
	     authList.add("Agatha Christy");
	     authList.add("Edgar Allen Poe");
	     authList.add("William Faulkner");
	     authList.add("John Steinbeck");
	     authList.add("John Grisham");
	     authList.add("George Orwell");
	     authList.add("H.P. Lovecraft");
	     authList.add("Roald Dahl");
	     authList.add("Prof Ed Nelson");
	     
	     Collections.sort(authList);

	     System.out.println(authList);

}
}
