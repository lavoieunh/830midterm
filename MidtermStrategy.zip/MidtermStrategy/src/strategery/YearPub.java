package strategery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class YearPub {

	public Integer yearspub;
	
	
	
	public YearPub() { 
	 List<Integer> yearspub = new ArrayList<Integer>();
	 yearspub.add(1900);
	 yearspub.add(1990);
	 yearspub.add(1876);
	 yearspub.add(1250);
	 yearspub.add(1475);
	 yearspub.add(1901);
	 yearspub.add(1976);
     yearspub.add(1955);
     yearspub.add(1961);
     yearspub.add(1855);
     yearspub.add(1832);
     yearspub.add(1821);
     yearspub.add(1913);
     yearspub.add(2001);
     yearspub.add(1654);
     yearspub.add(1984);
     yearspub.add(1998);
     yearspub.add(1972);
     yearspub.add(1900);
     yearspub.add(1998);
     yearspub.add(1992);
     
     Collections.sort(yearspub);

     System.out.println(yearspub);

}

	
}
