package decorating;

import java.io.*;

public class AdjectiveDecorator {
	

	public AdjectiveDecorator() {
		
			File worded = new File("adjectives.txt");

		{
			try (BufferedReader reader = new BufferedReader(new FileReader(worded))) {
		        //FileInputStream fstream = new FileInputStream(worded);
			    while (true) {
			        String line = reader.readLine();
			        if (line == null) {
			           break;
			        }
			    System.out.println(line);
			    }

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		}
		//return;
		
		} 
			
			}


