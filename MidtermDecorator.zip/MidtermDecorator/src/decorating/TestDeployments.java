package decorating;

import java.io.*;

public class TestDeployments {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		
		
		Words stink = new Words(); 
		System.out.println(stink); 
		
		AdjectiveDecorator wow = new AdjectiveDecorator();
		System.out.println(wow);
		
		VerbDecorator tough = new VerbDecorator(); 
		System.out.println(tough);
	}
}

