package decorating;

public class AdverbDecorator implements WordLife  {
	
	

		  
		
}

