package decorating;

import java.io.*;

public class Adverbage implements WordLife {

	File worded = new File("words.txt");

	@Override
	public String words() {
		try (BufferedReader reader = new BufferedReader(new FileReader(worded))) {
		    while (true) {
		        String line = reader.readLine();
		       if (line == null) {
		        break;
		       }
		    System.out.println(line);
		    }
		    
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return null;
	}		
	}

